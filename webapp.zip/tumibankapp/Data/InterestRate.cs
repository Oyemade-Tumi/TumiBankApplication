﻿
using System.ComponentModel.DataAnnotations;

namespace tumibankapp.Data
{
    public class InterestRate
    {
        [Key]    
        public int InterestRateId { get; set; }
        public double CurrentRate { get; set; }
        public double ApplyInterest { get; set; }
    }

}
